module.exports = {
  "prefixo": "e",
  "koedas": 0,
  "daily": 0,
  "vip": 0,
}
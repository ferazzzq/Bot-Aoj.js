module.exports =[{
  name: "<@$clientID>",
  nonPrefixed: true,
  code: `$reply <a:estrelinhasstelar:1104571637413728326>  <@$authorID>, **Ola**, Eu me chamo **Estelar**, e sou uma bot focada em economia global! Meu prefixo neste servidor é \`$getGuildVar[prefixo]\`, caso precise de ajuda utilize o comando \`$getGuildVar[prefixo]ajuda\` para mais informações.`

},{
  name: "<@!$clientID>",
  nonPrefixed: true,
  code: `$reply <a:estrelinhasstelar:1104571637413728326>  <@$authorID>, **Ola**, Eu me chamo **Estelar**, e sou uma bot focada em economia global! Meu prefixo neste servidor é \`$getGuildVar[prefixo]\`, caso precise de ajuda utilize o comando \`$getGuildVar[prefixo]ajuda\` para mais informações.`
}]
module.exports = [{
  name: "eval",
  aliases: ['v','evl'],
  code: `
  $eval[$message]
  $onlyForIDs[1091877189194100776;844287764634665040;<:emoji_1:1101826208259387462>  <@$authorID>, este comando é privado para os meus administradores!]`
},{
  name: "rr",
  code: `
  $reply
  $addButton[1;resetar;secondary;reset;no;🔄]
  Painel de controles da estelarbot
  Ping: \`$ping milissegundos.\`
  Comandos Ativos: \`$commandsCount\`
  $onlyForIDs[1091877189194100776;<:emoji_1:1101826208259387462>  <@$authorID>, este comando é privado para os meus administradores!]`
},{
    name:"reset",
    type:"interaction",
    prototype:"button",
    code:`
    $reply
    $updateCommands
  $interactionReply[painel de controles da estelarbot
  Ping: \`$ping milissegundos.\`
  Comandos Ativos: \`$commandsCount\`]`
}]

module.exports =[{
name: "daiiiilyytssjejdnd",
code: `
$setGlobalUserVar[koedas;$sum[$getGlobalUserVar[koedas];$random[1000;5000]];$authorID]
    $reply
    <@$authorID>
    $author[RECOMPENSA DIÁRIA;https://media.discordapp.net/attachments/1104940631995985973/1105810803107569705/15c3bd10f83389a25351d8898dee238e.png]
    $description[ <:koedas:1102060230168297545>  Você acabou de resgatar sua recompensa diária, e nele veio um total de **$numberSeparator[$random[1000;5000];.] koedas!** **\`[ você sabia que adiquirindo o premium você ganha o dobro de koedas no daily? e terá o cooldown reduzido. ]\`**
    
> <a:relogioestelar:1104915635655409676>  Para conseguir ver o tempo de resfriamento dos comandos utilize** \`[ $getGuildVar[prefixo]cooldowns ou $getGuildVar[prefixo]cd ]\`**]
$color[8B0000]
$addButton[1;Lembrete;secondary;daily_$authorID;false;<a:lembretestelar:1105963662398738512>]
`
},{
type: "interaction",
prototype: "button",
code: `
$sendMessage[ <:sinoamarelostelar:1105963609542099005>  <@$authorID>, seu daily esta pronto para ser resgatado!]
$wait[24h]
$interactionReply[<:certovermelhoestelar:1105810529253085234> - Lembrete definido! Te lembrarei em 24 horas;daily_$authorID;;;all;true]
$onlyIf[$splitText[2]==$authorID;]
$onlyIf[$splitText[1]==daily;]
$textSplit[$interactionData[customId];_]
`
}]
module.exports = ({
  name: "prefixo",
  aliases: ["set-prefix", "setprefix", "definir-prefixo", "definirprefixo", "prefix"],
  code: `
$setGuildVar[prefixo;$noescapingmessage[1]]

<:certostelar:1105520027190427679>  <@$authorID>, você alterou o prefixo com sucesso! novo prefixo **" $noescapingmessage[1] "**

$onlyif[$charcount[$noescapingmessage[1]]<=3;<:emoji_1:1101826208259387462>  <@$authorID>, o prefixo so pode ter 3 ou menos caracteres.
> **$getGuildVar[prefixo]setprefix** <novo prefixo>]
$onlyif[$checkcontains[$message[1];everyone;here]==false;<:emoji_1:1101826208259387462>  <@$authorID>, não utilize everyone nem here como prefixos.
> **$getGuildVar[prefixo]setprefix** <novo prefixo>]
$onlyif[$getGuildVar[prefixo]!=$message[1];<:emoji_1:1101826208259387462>  <$@authorID>, esse já é o prefixo atual do servidor!
> **$getGuildVar[prefixo]setprefix** <novo prefixo>]
$onlyif[$message!=;<:emoji_1:1101826208259387462>  <@$authorID>, **Argumentos inválidos**
> **$getGuildVar[prefixo]setprefix** <novo prefixo>]

$onlyPerms[administrator;<:emoji_1:1101826208259387462>  <$@authorID>, você precisa da permissão de \`Administrador\` para executar este comando!]
`})
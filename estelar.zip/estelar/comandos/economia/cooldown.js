module.exports = [{
  name: "cooldown",
  aliases: ['cd', 'cooldowns'],
  usage: "Mostra seus tempo de resfriamento ",
  code: `
  $reply
  $author[TEMPO DE RESFRIAMENTO - $userTag[$findUser[$message[1]]];https://media.discordapp.net/attachments/1104940631995985973/1105810803107569705/15c3bd10f83389a25351d8898dee238e.png]
  $description[

**  Daily:  \`$if[$get[daily;$findUser[$message[1]]]>=0;$replaceText[$replaceText[$replaceText[$parseDate[$get[daily;$findUser[$message[1]]];time];hour;hora];minute;minuto];second;segundo]; disponível]\`**]
$thumbnail[$userAvatar[$findUser[$message[1]]]]
$color[8B0000]
$let[daily;$getCooldownTime[24h;globalUser;daily;$findMember[$message[1]];yes]]
  
`}]
module.exports =[{
name: "daily",
code: `
$setGlobalUserVar[koedas;$sum[$getGlobalUserVar[koedas];$random[1000;5000]];$authorID]
$globalCooldown[24h;<:emoji_1:1101826208259387462>  <@$authorID>, você ainda está em tempo de resfriamento! você podera utilizar este comando novamente em \`%time%\` para coletar sua recompensa diária novamente!]

    $reply
    <@$authorID>
    $author[RECOMPENSA DIÁRIA;https://media.discordapp.net/attachments/1104940631995985973/1105810803107569705/15c3bd10f83389a25351d8898dee238e.png]
    $description[ <:koedas:1102060230168297545>  Você acabou de resgatar sua recompensa diária, e nele veio um total de **$numberSeparator[$random[1000;5000];.] koedas!** **\`[ você sabia que adiquirindo o premium você ganha o dobro de koedas no daily? e terá o cooldown reduzido. ]\`**
    
> <a:relogioestelar:1104915635655409676>  Para conseguir ver o tempo de resfriamento dos comandos utilize** \`[ $getGuildVar[prefixo]cooldowns ou $getGuildVar[prefixo]cd ]\`**]
$color[8B0000]
$addButton[1;Recompensa Coletada com Sucesso;secondary;daily;true;<:certovermelhoestelar:1105810529253085234> ]

`
}]
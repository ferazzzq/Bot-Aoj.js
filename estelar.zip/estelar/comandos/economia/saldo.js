module.exports = [{
  name: "atm",
  aliases: ['saldo','bal'],
  $if: 'v5',
  code: `
$reply
<:koedas:1102060230168297545>  <@$mentioned[1;true]>, Você tem um total de **$numberSeparator[$getGlobalUserVar[koedas;$mentioned[1;true]];.] Koedas! ( $abbreviate[$getGlobalUserVar[koedas;$mentioned[1;true]];1] )!**`
}]
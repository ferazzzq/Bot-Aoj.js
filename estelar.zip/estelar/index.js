const {AoiClient} = require("aoi.js");
const aoijs = require("aoi.js")

const bot = new AoiClient({
    token: "MTEwNDkwNzgxNjk2MTA0ODY4OA.GZuZif.AFRQF7e8w06PERUFwVliWIk2cZTEIev7PRoXA4",
    prefix: "$getGuildVar[prefixo]",
    intents: ["MessageContent", "Guilds", "GuildMessages", "GuildVoiceStates"],
    events: ["onMessage", "onInteractionCreate"],
    database: {
        type: "aoi.db",
        db: require("aoi.db"),
        tables: ["main"],
        path: "./database/",
        extraOptions: {
            dbType: "KeyValue"
        }
    }
});
bot.readyCommand({
      channel:"1106702291924426843",
      code:`
to on ze buceta
`
})
const loader = new aoijs.LoadCommands(bot);
loader.load(bot.cmd, './comandos/');

bot.variables(require("./variaveis/principal.js")); 
bot.status({
  text: "EstelarBot - Desenvolvimento.", 
  type: "PLAYING", 
  status: "online",
  time: 12 
});

bot.joinCommand({  
         channel: "829967269861261382",  
         code: `**Hey <@$authorID>!, Welcome to $serverName! Please read the Rules in <#829649951633047553> and Enjoy**` 
 }) 
 bot.onJoined() 
  
 bot.leaveCommand({  
         channel: "829967269861261382",  
         code: `**Goodbye $username, hope you had a Good Stay at $serverName**` 
 })